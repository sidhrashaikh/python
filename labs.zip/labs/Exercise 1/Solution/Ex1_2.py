#! /usr/bin/python

first = "Fred"
last = "Flintstone"
print(first, last)
print(first + " " + last)
