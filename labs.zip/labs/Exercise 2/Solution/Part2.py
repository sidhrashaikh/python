title = "The Flinstones"
director = "Brian levant"
year = 1994
duration = 91
cert = "PG"
print(title, "was directed by", director, "in", year)
print("Its duration is", duration, "and is a", cert, "certificate")
