print(type(title))
print(type(director))
print(type(year))
print(type(duration))
print(type(cert))

