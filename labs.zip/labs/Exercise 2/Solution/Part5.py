title = "Jaws"
duration = 91.0
year = 1994
summary = "My favourite movie is " + title + ". It was filmed in " + str(year) + " and runs for " + str(duration) + " mins "
print(summary)


