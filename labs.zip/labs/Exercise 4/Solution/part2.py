movie = "Local Hero, 111 minutes, Bill Forsyth, Burt Lancaster"

print("-" * len(movie))
print(movie.replace(",", ":"))
print("Film: " + movie[0:10])
print("Duration: " + movie[12:23])
print("Director: " + movie[25:37])
print("Starring: " + movie[39:])
print("-" * len(movie))

