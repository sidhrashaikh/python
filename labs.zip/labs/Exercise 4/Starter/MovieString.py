#! /usr/bin/python

movie = "Local Hero, 111 minutes, Bill Forsyth, Burt Lancaster"