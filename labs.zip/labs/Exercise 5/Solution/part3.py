movie = {"title": "Jaws", "director": "Steven Spielberg", "year": 1975, "duration": 124.0}
print("Title:" + movie["title"])
print("Year:" + str(movie["year"]))
print("Director:" + movie["director"])
