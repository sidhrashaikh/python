# What were you expecting?
# Well off you go then!

"""
“He’s not the Messiah – he’s a very naughty boy.”

“Look, I don’t think it ought to be blasphemy, just saying ‘Jehovah’.”
“You’re only making it worse for yourself!”

“Alright, but apart from the sanitation, the medicine, education, wine, public order, irrigation, roads, the fresh-water system, and public health, what have the Romans ever done for us?”

“What did he say?”
“I think it was, ‘blessed are the cheesemakers’.”

“Excuse me. Are you the Judean People’s Front?”
“F*** off! ‘Judean People’s Front’?. We’re the People’s Front of Judea!'”

“Did you say ‘ex-leper’?”
“That’s right, sir. 16 years behind a veil and proud of it, sir.”
“What’s this then?”
“It says ‘Romans go home’.”
“No it doesn’t. What’s Latin for ‘Roman’?”

“Look, you’ve got it all wrong. You don’t need to follow me. You don’t need to follow anybody. You’ve got to think for yourselves. You’re all individuals.”
“YES. WE’RE ALL INDIVIDUALS.”

“We are three wise men.”
“Well, what are you doing creeping around a cow shed at two o’clock in the morning? That doesn’t sound very wise to me.”

“I am not the Messiah!”
“I say you are, and I should know. I’ve followed a few.”

“Crucifixion?”
“Ah, no. Freedom. They said I hadn’t done anything, so I can go free and live on an island somewhere.”
“Oh, that´s jolly good. Well, off you go then.”
“Nah, I’m only pulling your leg, it’s crucifixion really!”
"""

