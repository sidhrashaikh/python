import movielib

movie = movielib.find_movie("Jaws")

print(movie)
