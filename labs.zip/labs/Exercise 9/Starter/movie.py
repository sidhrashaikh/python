title = "Jaws"
director = "Steven Spielberg"
year = 1975


def display_details():
    print("Title:", title)
    print("Director:", director)
    print("Year:", year)

