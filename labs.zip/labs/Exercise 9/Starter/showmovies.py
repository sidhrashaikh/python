import movie

movie.display_details()
